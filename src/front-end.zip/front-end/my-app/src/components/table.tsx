import { useMemo, useState } from 'react'


export type Bomba = {
  MUNICIPIO: string
  BAIRRO: string | null
  PROPRIETARIO: string
  NUMERO_INMETRO: string
  DATA_VERIFICACAO: string
  RESULTADO: string
}


function Table({
  dados,
  municipio,
  onMunicipioChange
}: {
  dados: Bomba[]
  municipio: string
  onMunicipioChange: (valor: string) => void
}) {

    const [bairro, setBairro] = useState('')
    const [data, setData] = useState('')

   
const bombasFiltradas = useMemo(() => {
  return dados.filter((bomba) => {
    return (
      (bomba.BAIRRO ?? '').toLowerCase().includes(bairro.toLowerCase()) &&
      (bomba.DATA_VERIFICACAO ?? '').includes(data)
    )
  })
}, [dados, bairro, data])


    return (



        <div className="grid-cols-4">
            <h2 className="mx-auto max-w-full px-3 text-center !text-[#1E1E1E] text-xl leading-tight sm:text-2xl">
                Tabela de Bombas em SP (com as cidades do Rio)
            </h2>

            <div className="w-full min-w-0">
                <div className="w-full overflow-x-auto">
                    <table className="w-full min-w-[900px] table-fixed border-collapse border border-white">
                        <thead>
                            <tr>
                                <th className="border border-white bg-[#1E1E1E] px-4 py-2 text-white">
                                    Município
                                </th>
                                <th className="border border-white bg-[#1E1E1E] px-4 py-2 text-white">
                                    Bairro
                                </th>
                                <th className="border border-white bg-[#1E1E1E] px-4 py-2 text-white">
                                    Proprietário
                                </th>
                                <th className="border border-white bg-[#1E1E1E] px-4 py-2 text-white">
                                    Inmetro
                                </th>
                                <th className="border border-white bg-[#1E1E1E] px-4 py-2 text-white">
                                    Verificado
                                </th>
                                <th className="border border-white bg-[#1E1E1E] px-4 py-2 text-white">
                                    Resultado
                                </th>
                            </tr>
                        </thead>

                        <tbody>
                            {bombasFiltradas.slice(0, 20).map((bomba, index) => (
                                    <tr key={`${bomba.NUMERO_INMETRO}-${index}`}>
                                    <td className="border border-gray-300 bg-white px-4 py-2">
                                        {bomba.MUNICIPIO}
                                    </td>
                                    <td className="border border-gray-300 bg-white px-4 py-2">
                                        {bomba.BAIRRO}
                                    </td>
                                    <td className="border border-gray-300 bg-white px-4 py-2">
                                        {bomba.PROPRIETARIO}
                                    </td>
                                    <td className="border border-gray-300 bg-white px-4 py-2">
                                        {bomba.NUMERO_INMETRO}
                                    </td>
                                    <td className="border border-gray-300 bg-white px-4 py-2">
                                        {bomba.DATA_VERIFICACAO?.slice(0, 10).split('-').reverse().join('/')}
                                    </td>
                                    <td
                                        className={`border border-gray-300 bg-white px-4 py-2 ${bomba.RESULTADO === 'Aprovado'
                                            ? 'text-[#008000]'
                                            : bomba.RESULTADO === 'Reprovado'
                                                ? 'text-[#900603]'
                                                : 'text-[#FDED00]'
                                            }`}
                                    >
                                        {bomba.RESULTADO}
                                    </td>
                                </tr>
                            ))}

                            {bombasFiltradas.length === 0 && (
                                <tr>
                                    <td
                                        colSpan={6}
                                        className="border border-white px-4 py-2 text-center"
                                    >
                                        Nenhum resultado encontrado.
                                    </td>
                                </tr>
                            )}
                        </tbody>
                    </table>
                </div> 
                
                    <div className="flex flex-wrap gap-3 border border-t-0 border-white bg-[#333333] px-4 py-3">
                        <input
                            type="text"
                            value={municipio}
                            onChange={(e) => onMunicipioChange(e.target.value)}
                            placeholder="Buscar por município"
                            className="border border-white bg-transparent px-3 py-2 text-white/80 placeholder:text-white/60 focus:outline-none"
                        />

                        <input
                            type="text"
                            value={bairro}
                            onChange={(event) => setBairro(event.target.value)}
                            placeholder="Buscar por bairro"
                            className="border border-white bg-transparent px-3 py-2 text-white/80 placeholder:text-white/60 focus:outline-none"
                        />

                        <input
                            type="text"
                            value={data}
                            onChange={(event) => setData(event.target.value)}
                            placeholder="Buscar por data: 06/07/25"
                            className="border border-white bg-transparent px-3 py-2 text-white/80 placeholder:text-white/60 focus:outline-none"
                        />

                    </div>
                </div>
            </div>
    )
}

export default Table