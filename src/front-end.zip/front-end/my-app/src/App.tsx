import { useEffect, useMemo, useState } from 'react'
import './App.css'
import Header from './components/header'
import Bar from './components/bar'
import Table from './components/table'
import Stats from './components/stats'
import type { Bomba } from './components/table'

function App() {

  const [bombas, setBombas] = useState<Bomba[]>([])
  const [municipioFiltro, setMunicipioFiltro] = useState('')

  useEffect(() => {
  const controller = new AbortController()

  const timer = setTimeout(() => {
    const rota = municipioFiltro.trim()
      ? `/api/bombas?municipio=${encodeURIComponent(municipioFiltro)}`
      : '/api/bombas'

    fetch(rota, { signal: controller.signal })
      .then(res => {
        if (!res.ok) throw new Error(`HTTP ${res.status}`)
        return res.json()
      })
      .then(data => setBombas(data.registros))
      .catch(erro => {
        if (!controller.signal.aborted) console.error(erro)
      })
  }, 300)

  return () => {
    clearTimeout(timer)
    controller.abort()
  }
}, [municipioFiltro])

  const ranking = useMemo(() => {
  const contagem: Record<string, number> = {}

    bombas.forEach((bomba) => {
      if (bomba.RESULTADO === 'Aprovado') {
        contagem[bomba.MUNICIPIO] = (contagem[bomba.MUNICIPIO] || 0) + 1
      }
    })

    return Object.entries(contagem)
      .map(([municipio, valor]) => ({ municipio, valor }))
      .sort((a, b) => b.valor - a.valor)
  }, [])


  return (
    <div className="min-h-screen bg-[#ADB9CA]">
      <Header />
      <Table dados={bombas} municipio={municipioFiltro} onMunicipioChange={setMunicipioFiltro}/>
      <Stats />
      <Bar dados={ranking} />
    </div>
  )
}

export default App