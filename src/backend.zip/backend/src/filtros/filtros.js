
export function normalizar(texto) {
  if (texto == null) return "";

  return String(texto)
    .normalize("NFKD")
    .replace(/[\u0300-\u036f]/g, "")
    .toUpperCase()
    .replace(/[^A-Z0-9 ]/g, " ")
    .replace(/\s+/g, " ")
    .trim();
}

export function filtrarPorTexto(dados, coluna, busca) {
  const buscaNormalizada = normalizar(busca);

  if (!buscaNormalizada) return [];

  const exatos = dados.filter(
    item => normalizar(item[coluna]) === buscaNormalizada
  );

  if (exatos.length > 0) {
    return exatos;
  }

  return dados.filter(
    item => normalizar(item[coluna]).includes(buscaNormalizada)
  );
}

export function filtrarPorMunicipio(dados, municipio) {
  return filtrarPorTexto(dados, "MUNICIPIO", municipio);
}