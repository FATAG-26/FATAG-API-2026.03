
import http from "node:http";
import { carregarJson } from "./carregarJson.js";
import { filtrarPorMunicipio } from "./filtros/filtros.js";

// Carrega os dados apenas uma vez
const dados = await carregarJson();

const servidor = http.createServer((req, res) => {
  const url = new URL(req.url, "http://localhost:8000");

  res.setHeader("Content-Type", "application/json; charset=utf-8");

  if (req.method === "GET" && url.pathname === "/api/bombas") {
    res.writeHead(200);

    const municipio = url.searchParams.get("municipio");

    const resultado = municipio?.trim()
        ? filtrarPorMunicipio(dados, municipio)
        : dados;

    res.end(JSON.stringify({
        total: resultado.length,
        registros: resultado
    }));

    return;
  }

  res.writeHead(404);
  res.end(JSON.stringify({ erro: "Rota não encontrada" }));
});

servidor.listen(8000, "0.0.0.0");
